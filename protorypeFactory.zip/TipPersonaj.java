public enum TipPersonaj {
    EROU,
    MONSTRU
}
