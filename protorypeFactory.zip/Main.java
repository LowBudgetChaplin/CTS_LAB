public class Main {
    public static void main(String[] args) {
        try {
            Personaj erou1 = PersonajPrototypeFactory.getPrototip(TipPersonaj.EROU);
            Personaj erou2 = PersonajPrototypeFactory.getPrototip(TipPersonaj.EROU);

            Personaj monstru1 = PersonajPrototypeFactory.getPrototip(TipPersonaj.MONSTRU);
            System.out.println(erou1);
            System.out.println(monstru1);
            erou1.ataca(monstru1);

            System.out.println(erou1);
            System.out.println(monstru1);

            monstru1.ataca(erou2);

            System.out.println(erou2);
            System.out.println(monstru1);

        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }



    }
}