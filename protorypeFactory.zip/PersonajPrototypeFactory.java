import java.util.HashMap;
import java.util.Map;

public class PersonajPrototypeFactory {

    private static Map<TipPersonaj, Personaj> personajMap;

    static{
        personajMap =  new HashMap<>();
        System.out.println("Incarcare map bloc static");
        personajMap.put(TipPersonaj.EROU, new Erou());
        personajMap.put(TipPersonaj.MONSTRU, new Monstru());

    }

    public static Personaj getPrototip(TipPersonaj tipPersonaj) throws CloneNotSupportedException {
        if(personajMap.containsKey(tipPersonaj)){
            return personajMap.get(tipPersonaj).clone();
        }
        return null;
    }
}
