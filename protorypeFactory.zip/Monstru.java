import java.util.ArrayList;

public class Monstru extends Personaj{
    private int dimensiune;

    @Override
    public void ataca(Personaj personaj) {
        if(personaj != null){
            personaj.nivelViata = personaj.nivelViata -10;
            this.dimensiune++;


        }
    }

    public Monstru() {
        this.dimensiune = 1;
        System.out.println("Lista arme monstru BD");
        this.listaArme = new ArrayList<>();
        listaArme.add("Coarne");
        listaArme.add("Apa");
    }

    @Override
    public String toString() {
        return "Monstru{" +
                "dimensiune=" + dimensiune +
                ", nivelViata=" + nivelViata +
                ", listaArme=" + listaArme +
                ", listaTexturi=" + listaTexturi +
                '}';
    }
}
