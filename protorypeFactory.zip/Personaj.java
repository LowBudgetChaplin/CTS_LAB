import java.util.ArrayList;
import java.util.List;

public abstract class Personaj implements Cloneable {
    protected int nivelViata;
    protected List<String> listaArme;
    protected List<String> listaTexturi;

    public abstract void ataca(Personaj personaj);

    public Personaj() {
        this.nivelViata = 100;
        System.out.println("Lista texturi generale BD");
        this.listaTexturi= new ArrayList<>();
        this.listaTexturi.add("Textura 1 general");
        this.listaTexturi.add("Textura 2 general");
    }

    @Override
    protected Personaj clone() throws CloneNotSupportedException {
        Personaj personaj = (Personaj) super.clone();
        personaj.listaArme = new ArrayList<>(this.listaArme);
        return personaj;
    }


}
