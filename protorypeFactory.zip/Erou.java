import java.util.ArrayList;

public class Erou extends Personaj{

    @Override
    public void ataca(Personaj personaj) {
        if(personaj != null){
            personaj.nivelViata = personaj.nivelViata -10;
            if(personaj.listaArme != null && !listaArme.isEmpty()){
                this.listaArme.add(personaj.listaArme.get(0));
                personaj.listaArme.remove(0);
            }
        }

    }

    public Erou() {
        System.out.println("Lista arme erou BD");
        this.listaArme = new ArrayList<>();
        listaArme.add("Sabie");
        listaArme.add("Scut");
    }


    @Override
    public String toString() {
        return "Erou{" +
                "nivelViata=" + nivelViata +
                ", listaArme=" + listaArme +
                ", listaTexturi=" + listaTexturi +
                '}';
    }
}
